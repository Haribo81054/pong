from drawille import Turtle, Canvas
c = Canvas()

c.set_text(1,1,"123")