from drawille import Turtle
from rozgrywka import Rozgrywka
from ekran import Ekran

rozgrywka = Rozgrywka(1)
rozgrywka.start()